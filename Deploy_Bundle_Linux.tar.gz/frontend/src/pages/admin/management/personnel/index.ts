// Personnel Management Module - Barrel Export
export { default as PersonnelTab } from './PersonnelTab';
export { usePersonnelManagement } from './usePersonnelManagement';
export * from './types';
